# ArduBreakout

Brick breaking game in the vein of Atari's *Breakout*.

Control the paddle with the directional keys to keep a ball bouncing against a brick wall until all of the bricks are broken.

High scores are saved to EEPROM and can be saved through Arduboy restarts.
