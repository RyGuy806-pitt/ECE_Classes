// Generated from Images/enemy.png
constexpr uint8_t skeletonSpriteData_numFrames = 2;
extern const uint16_t skeletonSpriteData[];
// Generated from Images/mage.png
constexpr uint8_t mageSpriteData_numFrames = 2;
extern const uint16_t mageSpriteData[];
// Generated from Images/torchalt1.png
constexpr uint8_t torchSpriteData1_numFrames = 1;
extern const uint16_t torchSpriteData1[];
// Generated from Images/torchalt2.png
constexpr uint8_t torchSpriteData2_numFrames = 1;
extern const uint16_t torchSpriteData2[];
// Generated from Images/fireball2.png
constexpr uint8_t projectileSpriteData_numFrames = 1;
extern const uint16_t projectileSpriteData[];
// Generated from Images/fireball.png
constexpr uint8_t enemyProjectileSpriteData_numFrames = 1;
extern const uint16_t enemyProjectileSpriteData[];
// Generated from Images/entrance.png
constexpr uint8_t entranceSpriteData_numFrames = 1;
extern const uint16_t entranceSpriteData[];
// Generated from Images/exit.png
constexpr uint8_t exitSpriteData_numFrames = 1;
extern const uint16_t exitSpriteData[];
// Generated from Images/urn.png
constexpr uint8_t urnSpriteData_numFrames = 1;
extern const uint16_t urnSpriteData[];
// Generated from Images/sign.png
constexpr uint8_t signSpriteData_numFrames = 1;
extern const uint16_t signSpriteData[];
// Generated from Images/crown.png
constexpr uint8_t crownSpriteData_numFrames = 1;
extern const uint16_t crownSpriteData[];
// Generated from Images/coins.png
constexpr uint8_t coinsSpriteData_numFrames = 1;
extern const uint16_t coinsSpriteData[];
// Generated from Images/scroll.png
constexpr uint8_t scrollSpriteData_numFrames = 1;
extern const uint16_t scrollSpriteData[];
// Generated from Images/chest.png
constexpr uint8_t chestSpriteData_numFrames = 1;
extern const uint16_t chestSpriteData[];
// Generated from Images/chestopen.png
constexpr uint8_t chestOpenSpriteData_numFrames = 1;
extern const uint16_t chestOpenSpriteData[];
// Generated from Images/potion.png
constexpr uint8_t potionSpriteData_numFrames = 1;
extern const uint16_t potionSpriteData[];
// Generated from Images/bat.png
constexpr uint8_t batSpriteData_numFrames = 2;
extern const uint16_t batSpriteData[];
// Generated from Images/spider.png
constexpr uint8_t spiderSpriteData_numFrames = 2;
extern const uint16_t spiderSpriteData[];
// Generated from Images/hand1.png
extern const uint8_t handSpriteData1[];
// Generated from Images/hand2.png
extern const uint8_t handSpriteData2[];
// Generated from Images/textures.png
constexpr uint8_t wallTextureData_numTextures = 1;
extern const uint16_t wallTextureData[];
// Generated from Images/font.png
extern const uint8_t fontPageData[];
// Generated from Images/heart.png
extern const uint8_t heartSpriteData[];
// Generated from Images/mana.png
extern const uint8_t manaSpriteData[];
