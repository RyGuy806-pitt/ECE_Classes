#include <string>
#include <vector>
#include <iostream>
#include <locale> 
#include "FindPalindrome.hpp"

using namespace std;

//------------------- HELPER FUNCTIONS -----------------------------------------

// non-class helper functions go here, should be declared as "static" so that
// their scope is limited

// helper function to convert string to lower case
static void convertToLowerCase(string & value)
{
	locale loc;
	for (int i=0; i<value.size(); i++) {
		value[i] = tolower(value[i],loc);
	}
}

//------------------- PRIVATE CLASS METHODS ------------------------------------

// private recursive function. Must use this signature!
void FindPalindrome::recursiveFindPalindromes(vector<string> candidateStringVector, vector<string> currentStringVector)
{
  bool check=false;
  string hold, finalstr;
  vector<string> combo, fhalf, shalf, recombo;
  if(currentStringVector.size()<=3){
  for(int k = 0; k<currentStringVector.size(); k++){
    if(currentStringVector.size()<=2){
       for(int j = 0; j<2; j++){
	  if(currentStringVector.size()==2){
	    for(int i = 0; i<2; i++){
	      candidateStringVector.push_back(currentStringVector.at(i));
	    }
	  }
	  if(currentStringVector.size()==1){//only when first string is added
	     candidateStringVector.push_back(currentStringVector.at(0));
	  }
       
	  if(cutTest1(candidateStringVector)==true){//first check
    for(int n = 0; n<candidateStringVector.size()/2; n++){
      fhalf.push_back(candidateStringVector.at(n));//split halves
      shalf.push_back(candidateStringVector.at(candidateStringVector.size()-n-1));
    }
    if(cutTest2(fhalf, shalf)==true){//second check
      for(int o = 0; o<candidateStringVector.size(); o++){
	finalstr += candidateStringVector.at(o);//put all in a string
      }
      for(int p = 0; p<candidateStringVector.size(); p++){
	recombo.push_back(candidateStringVector.at(p));
      }
      if(isPalindrome(finalstr)==true){//final check
      add(candidateStringVector);
      }
      }
    fhalf.clear();//reset all test values
      shalf.clear();
      finalstr = "";
      recombo.clear();
     }
	  candidateStringVector.pop_back();
	  if(currentStringVector.size()>1){
	    candidateStringVector.pop_back();//only rotate when size more than one string is contained
  hold = currentStringVector.at(currentStringVector.size()-1);
  currentStringVector.at(currentStringVector.size()-1) = currentStringVector.at(currentStringVector.size()-2);
  currentStringVector.at(currentStringVector.size()-2) = hold;
	  }
      }
    return;
  }
     else{
       //move one value to candidate, next time will go to end
      candidateStringVector.push_back((currentStringVector.at(currentStringVector.size()-1)));
      combo.push_back(currentStringVector.at(currentStringVector.size()-1));
      currentStringVector.pop_back();
      // for(int r = 2; r<currentStringVector.size()+candidateStringVector.size();r++){
	/* if(currentStringVector.size()>2){
	hold = currentStringVector.at(r-1);
      currentStringVector.at(r-1) = currentStringVector.at(r-2);
      currentStringVector.at(r-2) = hold;
      }*/
    recursiveFindPalindromes(candidateStringVector, currentStringVector);
       }//for r : combo has improper evaluation
      candidateStringVector.pop_back();
      for(int l = 0; l<currentStringVector.size(); l++){
	combo.push_back(currentStringVector.at(l));//rotate all of combo
      }
      currentStringVector.clear();
      for(int m = 0; m<combo.size(); m++){
	currentStringVector.push_back(combo.at(m));
	//std::cout<<combo.at(m)<<std::endl;
	}
      combo.clear();//reset combo
      // }
  }
  }
  else{//for every vector size greater than 3
    for(int every=currentStringVector.size()-1;every>-1 ; every--){
      //will move the first string to candidate
      hold = currentStringVector.at(currentStringVector.size()-1);
      //std::cout<<hold<<std::endl;
      currentStringVector.pop_back();
      candidateStringVector.push_back(hold);
      //std::cout<<candidateStringVector.size()<<std::endl;
      recursiveFindPalindromes(candidateStringVector,currentStringVector);
      //recall function
      currentStringVector.push_back(hold);
      //shift that value to the back
      for(int rotate=0; rotate<currentStringVector.size()-1;rotate++){
	 hold = currentStringVector.at(rotate);
	 currentStringVector.at(rotate) = currentStringVector.at(rotate+1);
	 currentStringVector.at(rotate+1) = hold;
      }
      candidateStringVector.pop_back();
      //remove from candidate to calculate for each string as the first string
    }
  }
}


// private function to determine if a string is a palindrome (given, you
// may change this if you want)
bool FindPalindrome::isPalindrome(string currentString) const
{
	locale loc;
	// make sure that the string is lower case...
	convertToLowerCase(currentString);
	// see if the characters are symmetric...
	int stringLength = currentString.size();
	for (int i=0; i<stringLength/2; i++) {
		if (currentString[i] != currentString[stringLength - i - 1]) {
			return false;
		}
	}
	return true;
}

//------------------- PUBLIC CLASS METHODS -------------------------------------

FindPalindrome::FindPalindrome()
{
  Palindrome_holder.resize(0);
  Vector_Palindrome.resize(0);
}

FindPalindrome::~FindPalindrome()
{
  Palindrome_holder.clear();
  Vector_Palindrome.clear();
}

int FindPalindrome::number() const
{
  return Num;//returns total number of palindromes
}

void FindPalindrome::clear()
{
  Vector_Palindrome.clear();//clears both vectors
  Palindrome_holder.clear();
}

bool FindPalindrome::cutTest1(const vector<string> & stringVector)
{
  std::string temp = "";
  int temparr[26];
    for(int i = 0; i<26;i++){
      temparr[i] = 0;
  }
    for(int i = 0; i<stringVector.size(); i++){
      temp += stringVector[i];
    }
    convertToLowerCase(temp);
    for(int i =0; i< temp.length(); i++){
      ++temparr[temp[i]-97];
    }
    int flag = 2;
    for(int i = 0; i<26; i++){
      if(temparr[i]%2 == 1){
	if(!(--flag)){//if more than 1 odd instance
	  return false;
	}
      }
    }
	return true;
}

bool FindPalindrome::cutTest2(const vector<string> & stringVector1,
                              const vector<string> & stringVector2)
{
  string smallstring, largestring, str1 = "", str2 = "";
  for(int i = 0; i < stringVector1.size(); i++){
    str1 += stringVector1[i];//takes the two halves
  }
  for(int i = 0; i < stringVector2.size(); i++){
    str2 += stringVector2[i];
  }
  convertToLowerCase(str1);//converts to lower case
  convertToLowerCase(str2);

  smallstring = str1.length() <= str2.length() ? str1: str2;
  largestring = smallstring == str1 ? str2 : str1;//compares contained values

  int tempa1[26];//one space per letter of alphabet
  int tempa2[26];

  for(int i = 0; i<26; i++){
    tempa1[i] = 0;//initializes to 0
    tempa2[i] = 0;
  }

  for(int i = 0; i<smallstring.length(); i++){
    ++tempa1[smallstring[i]-97];
  }
  for(int i = 0; i<largestring.length(); i++){
    ++tempa2[largestring[i]-97];
  }
  for(int i = 0; i<26; i++){
    if(tempa1[i] > tempa2[i]){//compares two halves
      return false;
    }
  }
	return true;
}

bool FindPalindrome::add(const string & value)
{
  bool retval = true;
  char s[value.length()];
  string hold;
  for(int j = 0; j<value.size(); j++){
    s[j] = value[j];
      if(!((s[j]<='z' && s[j]>='a')||(s[j]<='Z' && s[j]>='A'))){
	retval = false;//makes sure only elligible words are input
      }
    }
  for(int i = 0; i<Palindrome_holder.size(); i++){
    if(Palindrome_holder.at(i)==value){
      retval = false;//checks if word has already been input
    }
  }
  if(retval == true){
    Palindrome_holder.push_back(value);
    Num = 0;//resets palindrome counter value
  }
  vector<string> candidate;
  recursiveFindPalindromes(candidate, Palindrome_holder);//recalcs number each time a string is added
  return retval;
}

bool FindPalindrome::add(const vector<string> & stringVector)
{
  int s = Vector_Palindrome.size();
  s++;
  bool retval = true;
  Vector_Palindrome.resize(s);
  for(int i = 0; i<s; i++){
    if(Vector_Palindrome.at(i) == stringVector){
      retval = false;//if the palindrome is already contained, it will not count as a new palindrome
    }
  }
  if(retval==true){
    if(stringVector.size()==Palindrome_holder.size()){//checks for all terms being used in the palindrome
    Vector_Palindrome.push_back(stringVector);
    Num++;//adds one to total number of palindromes
    }
    else{
      retval = false;
    }
  }
	return retval;
}

vector< vector<string> > FindPalindrome::toVector() const//returns all the palindromes found
{
  return Vector_Palindrome;
}

