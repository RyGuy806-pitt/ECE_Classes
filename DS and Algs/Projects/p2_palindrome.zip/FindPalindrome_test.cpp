#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_COLOUR_NONE
#include "catch.hpp"
#include "FindPalindrome.hpp"

// There should be at least one test per FindPalindrome method

TEST_CASE( "Test FindPalindrome add a non-allowable word", "[FindPalindrome]" )
{
	INFO("Hint: add a single non-allowable word");
	FindPalindrome b;
	REQUIRE(!b.add("kayak1"));
}

TEST_CASE( "add test", "[test 1]"){
  FindPalindrome b;
  REQUIRE(b.add("a"));
}

TEST_CASE( "palindrome", "[test 2]"){
  FindPalindrome b;
  b.add("ka");
  b.add("yak");
  REQUIRE(b.number()==1);
}

TEST_CASE( "factorial", "[test 3]"){
  FindPalindrome b;
  b.add("a");
  REQUIRE(!(b.add("a")));
  b.add("aa");
  REQUIRE(b.number()==2);
  b.add("aaa");
  REQUIRE(b.number()==6);
  b.add("aaaa");
  REQUIRE(b.number()==24);
  b.add("aaaaa");
  REQUIRE(b.number()==120);
}

TEST_CASE( "kayak", "[test 4]" ){
  FindPalindrome b;
  b.add("kayak");
  REQUIRE(b.number()==1);
}

TEST_CASE( "Caps", "[Test 5]"){
  FindPalindrome b;
  b.add("a");
  b.add("Aa");
  b.add("AaA");
  REQUIRE(b.number()==6);
}

TEST_CASE( "toVector", "[Test 6]" ){
  FindPalindrome b;
  b.add("a");
  std::vector<std::vector<std::string>> holder;
  std::vector<std::string> hold;
  holder.resize(3);
  hold.push_back("a");
  holder.at(1)=hold;
  REQUIRE(b.toVector()==holder);
}

TEST_CASE( "add2", "[Test 7]"){
  FindPalindrome b;
  std::vector<std::string> hold;
  hold.push_back("a");
  b.add("a");
  
  REQUIRE(!(b.add(hold)));
}
