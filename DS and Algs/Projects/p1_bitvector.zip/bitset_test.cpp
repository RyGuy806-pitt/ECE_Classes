#define CATCH_CONFIG_MAIN
#define CATCH_CONFIG_COLOUR_NONE
#include "catch.hpp"

#include "bitset.hpp"

// THIS IS JUST AN EXAMPLE
// There should be at least one test per Bitset method

TEST_CASE( "Test bitset construction", "[bitset]" ) {

    Bitset b;  
    REQUIRE(b.size() == 8);
    REQUIRE(b.good());
}

TEST_CASE( "Test bit changed size", "Test 1" ){
  Bitset b(15);
  REQUIRE(b.size() == 15);
  REQUIRE(b.good());
}

TEST_CASE( "INVALID bit test", "Test 2"){
  Bitset b("00001234");
  REQUIRE(b.size() == 8);
  bool false_array = (!(b.good()));
  REQUIRE(false_array);
}

TEST_CASE( "VALID bit test", "Test 3"){
  Bitset b("00001111");
  REQUIRE(b.size() == 8);
  REQUIRE(b.good());
}

TEST_CASE( "toggle test", "Test 4"){
  Bitset b;
  b.toggle(0);
  REQUIRE(b.test(0));
}

TEST_CASE( "reset test", "Test 5"){
  Bitset b;
  b.toggle(0);
  b.reset(0);
  REQUIRE(!(b.test(0)));
}

TEST_CASE( "invalid set", "Test 6"){
  Bitset b;
  b.set(9);
  REQUIRE(!(b.good()));
}

TEST_CASE( "as string", "Test 7"){
  Bitset b;
  REQUIRE(b.asString()=="00000000");
}
