#include "bitset.hpp"
#include <iostream>
using namespace std;

// TODO
Bitset::Bitset(){
  arrayptr=new int[8];
  for(int i=0; i<8; i++){
    arrayptr[i]=0;
  }
  array_size = 8;
}

Bitset::Bitset(intmax_t size){
  arrayptr=new int[size];
    for(int i=0; i<size; i++){
    arrayptr[i]=0;
  }
  array_size = size;
}

Bitset::Bitset(const string & value){
  array_size = value.length();
  arrayptr = new int[array_size];
  string sub;
  for(int i=0; i<array_size; i++){
    sub = value.substr(i, 1);
    if(sub=="1"){
      set(i);
    }
    else if(sub=="0"){
      reset(i);
    }
    else{
      validity = false;
    }
  }
}

Bitset::~Bitset(){
  delete [] arrayptr;
}

intmax_t Bitset:: size() const{
  return array_size;
}

bool Bitset:: good() const{
  /* for(int i = 0; i<size(); i++){
    if((arrayptr[i]!=0) &&  (arrayptr[i]!=1)){
      return validity;
    }
  }
  return validity;*/
  return validity;
}

void Bitset:: set(intmax_t index){
  if(index<size()){
  arrayptr[index] = 1;
  }
  else{
    validity = false;
  }
}

void Bitset:: reset(intmax_t index){
  if(index<size()){
  arrayptr[index] = 0;
  }
  else{
    validity = false;
  }
}

void Bitset:: toggle(intmax_t index){
  if(index<size()){
    if(arrayptr[index] == 1){
    arrayptr[index] = 0;
    }
    else{
      arrayptr[index] = 1;
    }
  }
  else{
    validity = false;
  }
}

bool Bitset:: test(intmax_t index){
  if(index<size()){
    if(arrayptr[index] == 1){
      return true;
    }
    else{
      return false;
    }
  }
  else{
    validity = false;
  }
  return false;
}

string Bitset:: asString() const{
  int take = 0;
  string return_string;
  for(int i = 0; i<size(); i++){
    take = arrayptr[i];
    return_string += to_string(take);
  }
  return return_string;
}
