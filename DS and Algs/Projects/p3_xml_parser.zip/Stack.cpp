//  Adapated from Frank M. Carrano and Timothy M. Henry.

/** ADT Stack implementation.
    @file Stack.cpp */

#include <iostream>
#include <cstddef>
#include "Stack.hpp"
#include "Node.hpp"

// TODO: Implement the constructor here
template<class ItemType>
Stack<ItemType>::Stack() 
{
  currentSize = 0;
  headPtr = new Node<ItemType>();
}  

// TODO: Implement the destructor here
template<class ItemType>
Stack<ItemType>::~Stack()
{
  delete headPtr;
}  

// TODO: Implement the isEmpty method here
template<class ItemType>
bool Stack<ItemType>::isEmpty() const
{
  if(currentSize == 0){
	return true;
  }
  else{
    return false;
  }
}  // end isEmpty

// TODO: Implement the size method here
template<class ItemType>
int Stack<ItemType>::size() const
{
	return currentSize;
}  // end size

// TODO: Implement the push method here
template<class ItemType>
bool Stack<ItemType>::push(const ItemType& newItem)
{
  Node<ItemType>* newNodePtr = new Node<ItemType>();
  Node<ItemType>* holdptr = headPtr;
  for(int i = 0; i<currentSize;i++){
    holdptr = holdptr->getNext();
  }
  holdptr->setNext(newNodePtr);
  holdptr->setItem(newItem);
  currentSize++;
	return true;
}  // end push

// TODO: Implement the peek method here
template<class ItemType>
ItemType Stack<ItemType>::peek() const throw(logic_error)
{
  Node<ItemType>* holdptr = headPtr;
  for(int i = 1; i<currentSize; i++){
   holdptr = holdptr->getNext();
  }
  ItemType returnItem = holdptr->getItem();
	return returnItem;
}  // end peek

// TODO: Implement the pop method here
template<class ItemType>
bool Stack<ItemType>::pop() 
{
  if(currentSize == 0){
    return false;
  }
  Node<ItemType>* holdptr = headPtr;
  if(currentSize>1){
  for(int i = 1; i<currentSize; i++){
    holdptr = holdptr->getNext();
  }
  holdptr->setNext(nullptr);
  }
  if(currentSize==1){
    headPtr = new Node<ItemType>();
  }
  currentSize--;
	return true;
}  // end pop

// TODO: Implement the clear method here
template<class ItemType>
void Stack<ItemType>::clear()
{
  headPtr = nullptr;
}  // end clear

