// Project 3 -- XML Parsing Project

/** XML parsing class implementation.
    @file XMLParser.cpp */

#include <string>
#include <assert.h>
#include "XMLParser.hpp"

static std::string deleteAttributes(std::string);

static bool valid(std::string);
// TODO: Implement the constructor here
XMLParser::XMLParser()
{
  elementNameBag = new Bag<std::string>;//new Bag item
  parseStack = new Stack<std::string>;//new stack item
}  

// TODO: Implement the destructor here
XMLParser::~XMLParser()
{
  delete elementNameBag;//delete pointers
  delete parseStack;
  tokenizedInputVector.clear();
}  

// TODO: Implement the tokenizeInputString method
bool XMLParser::tokenizeInputString(const std::string &inputString)
{
  std::string Content = "";//start blank strings
  std::string TagName = "";
  TokenStruct hold;//TokenStruct item
  int i = 0;
  while(i < inputString.size()){//run until end of massive string
    if(hold.tokenType == CONTENT){
      i--;
    }
    if(inputString == ""){
      return false;
    }
    if(inputString[i] == '<'){
      int end = 0;//reset end
      int j = i;//start from i
      while(j < inputString.size()){
	if(inputString[j] == '>'){//find '>'
	  end = j;//mark index
	  break;
	}
	j++;//increment j by one to not freeze loop
      }
      if(inputString[i+1] == '?'){
	hold.tokenType = DECLARATION;//type declation if '?' is second
	Content = inputString.substr(i+2,end-i-3);//get rid of '?'s
	hold.tokenString = Content;
	tokenizedInputVector.push_back(hold);//add to vector (no tag made)
	i = end+1;//increment by 1
      }
      else if(inputString[i+1] == '/'){//if '/' is second
	hold.tokenType = END_TAG;//endtag type
	Content = inputString.substr(i+2, end-i-2);//delete unneeded characters
	hold.tokenString = Content;
	tokenizedInputVector.push_back(hold);//put in vector
	if(valid(hold.tokenString)==true){//check for validity
          return false;
        }
	i = end+1;//increment
	hold.tokenString = "";//resent string
      }
      else if(inputString[end -1] == '/'){//'/' at end
	hold.tokenType = EMPTY_TAG;//empty tag type
	Content = inputString.substr(i,end-i);//take proper string for delete
	hold.tokenString = deleteAttributes(Content);//deletes brackets
	tokenizedInputVector.push_back(hold);//add to vector
	elementNameBag->add(hold.tokenString);//add tag name to vector
	if(valid(hold.tokenString)==true){//test for validity
	  return false;
	}
	i = end+1;//increment
	hold.tokenString ="";//clear
      }
      else{
	hold.tokenType = START_TAG;//start tag type
	Content = inputString.substr(i, end-i+1);//increment for delete
	hold.tokenString = deleteAttributes(Content);//delete
	tokenizedInputVector.push_back(hold);//add to vector
	elementNameBag->add(hold.tokenString);//add to bag
	if(valid(hold.tokenString)==true){//test for validity
          return false;
        }
	i = end+1;//increment
	hold.tokenString = "";//reset
      }
    }
    else{
      hold.tokenType = CONTENT;//no brackets
      hold.tokenString = "";//reset string
      while(inputString[i] != '<'){//until next '<'
	if(i<inputString.size()){
	hold.tokenString+=inputString[i];
	i++;//add content to string one by one
	}
	else{
	  break;
	}
      }
      i++;
      if(hold.tokenString == " " || hold.tokenString == "\n"){
	hold.tokenString = " ";//if there is nothing
	}
      else{
	tokenizedInputVector.push_back(hold);
      }
    }
  }
  if(hold.tokenType == CONTENT){
  tokenizedInputVector.pop_back();//delete end extra
  }
	return true;
} 

// TODO: Implement a helper function to delete attributes from a START_TAG
// or EMPTY_TAG string (you can change this...)
static std::string deleteAttributes(std::string input)
{
  std::string SubStr;
  int index;
  bool loop = false;
  for(int i = 0; i<input.size()-1; i++){
    if(input.substr(i,1)==" "){//if space then mark location
      if(loop == false){//only first time it happens the index will be marked
	index = i;//index of the space
	loop = true;//prevent recalc of the index
      }
    }
  }
  if(loop == false){//if no space is found
    index = input.size()-1;//second to last character is indexed
  }
  SubStr = input.substr(1,index-1);
	return SubStr;
}

// TODO: Implement the parseTokenizedInput method here
bool XMLParser::parseTokenizedInput()
{
  if(tokenizedInputVector.size() == 0){
    return false;
  }
  int count = 0;//counter to go through
  while(count < tokenizedInputVector.size()){//check each index
    if(tokenizedInputVector[count].tokenType == START_TAG){//if type matches
      parseStack->push(tokenizedInputVector[count].tokenString);//add to stack
    }
    else if(tokenizedInputVector[count].tokenType == END_TAG){
      if(parseStack->peek() == tokenizedInputVector[count].tokenString){
	parseStack->pop();//delete start from stack if end appears
      }
      else{
	parseStack->push(tokenizedInputVector[count].tokenString);//push ends onto stack otherwise
      }
    }
    count++;//increment
  }
  if(parseStack->isEmpty()){//if empty stack
    return true;
  }
  else{
	return false;
  }
}

// TODO: Implement the clear method here
void XMLParser::clear()
{
  tokenizedInputVector.clear();
}

vector<TokenStruct> XMLParser::returnTokenizedInput() const
{
	return tokenizedInputVector;
}

// TODO: Implement the containsElementName method
bool XMLParser::containsElementName(const std::string &inputString) const
{
  bool retval = false;
  retval = elementNameBag->contains(inputString);//use bag contains function
	return retval;
}

// TODO: Implement the frequencyElementName method
int XMLParser::frequencyElementName(const std::string &inputString) const
{
  int fr;
  fr = elementNameBag->getFrequencyOf(inputString);//use frequency function
	return fr;
}

static bool valid(std::string input){
  bool retval = false;
  std::string invalid = "!#$%&'()*+,/;<=>?@[\\]^'{|}~\"";//not allowed
  std::string numeric = "0123456789-,.";//cant be first
  for(int f = 0; f < numeric.size(); f++){//check each character
    if(numeric[f] == input[0]){//against first character
      retval = true;//ifso set true
    }
  }
  for(int r = 0; r< input.size(); r++){
    for(int r2 = 0; r2 < invalid.size(); r2++){
      if(invalid[r2] == input[r]){//check all characters against eachother
	retval = true;
      }
    }
  }
  return retval;
}
