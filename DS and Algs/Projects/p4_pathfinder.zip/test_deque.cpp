#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "deque.hpp"


TEST_CASE("is empty", "[Test 1]") {
  Deque<int> test;
  REQUIRE(test.isEmpty());
}

TEST_CASE("add", "[Test 2]") {
  Deque<int> test;
  test.pushFront(1);
  REQUIRE(test.front()==1);
}

TEST_CASE("multi add", "[Test 3]"){
  Deque<int> test;
  test.pushFront(1);
  test.pushFront(2);
  REQUIRE(test.front()==2);
}

TEST_CASE("pop", "[Test 4]"){
  Deque<int> test;
  test.pushFront(1);
  test.pushFront(2);
  test.popFront();
  REQUIRE(test.front()==1);
}

TEST_CASE("back", "[Test 5]"){
  Deque<int> test;
  test.pushFront(1);
  test.pushFront(2);
  REQUIRE(test.back()==1);
}

TEST_CASE("add back", "[Test 6]") {
  Deque<int> test;
  test.pushBack(1);
  REQUIRE(test.back()==1);
  REQUIRE(test.front()==1);
}

TEST_CASE("multi add back", "[Test 7]"){
  Deque<int> test;
  test.pushBack(1);
  test.pushBack(2);
  REQUIRE(test.back()==2);
  REQUIRE(test.front()==1);
}

TEST_CASE("pop front", "[Test 8]"){
  Deque<int> test;
  test.pushBack(1);
  test.pushBack(2);
  test.popFront();
  test.popFront();
  REQUIRE(test.isEmpty());
}

TEST_CASE("pop back", "[Test 8]"){
  Deque<int> test;
  test.pushBack(1);
  test.pushBack(2);
  test.popBack();
  test.popBack();
  REQUIRE(test.isEmpty());
}
