#include <iostream>
#include <fstream>
#include <string>
#include "lib/image.h"
#include "deque.hpp"

struct CO{
  int RW, CL;
  CO(){
  }
  CO(int in_1, int in_2){
    RW = in_1;
    CL = in_2;
  }
};

template class Deque<CO>;

int main(int argc, char *argv[])
{
  if( argc != 3){
    std::cout<<"Error! Too many inputs"<<std::endl;
    return EXIT_FAILURE;
  }

  std::ifstream inputfile(argv[1]);

  if(inputfile){}
  else{
    std::cout<<"Error! porblem with File"<<std::endl;
    return EXIT_FAILURE;
    }

  std::string outputfile = argv[2];
  if(outputfile.substr(outputfile.length() -4, 4) == ".png"){
  }
  else{
    std::cout<<"Error! Invalid file name"<<std::endl;
    return EXIT_FAILURE;
  }

  Image<Pixel> maze;//input image
  maze = readFromFile(argv[1]);
  Deque<CO> dq;//deque object
  int width, height, row, column, counter;
  width = maze.width();//dimensions
  height = maze.height();
  std::vector<std::vector<bool>> searched;
  searched.resize(height);
  for(int i = 0; i<height; i++){
    searched[i].resize(width);
    for(int j = 0; j<width; j++){
      searched[i][j] = false;//set all as unsearched
    }
  }
  counter = 0;//number of red spaces
  for(int r = 0; r<width; r++){
    for(int c = 0; c<height; c++){
      if(maze(r, c)==RED){
	row = r;
	column = c;
	counter++;
      }
    }
  }
  bool compare = false;
  dq.pushBack({row, column});
  while(dq.isEmpty()==false){
    row = dq.front().RW;
    column = dq.front().CL;
    dq.popFront();

    if(row == height - 1 || row == 0 || column == width - 1 || column == 0){
      maze(row, column) = GREEN;
      compare = true;
      break;
    }

    if(searched[row-1][column] == false && maze(row-1, column) == WHITE){
      dq.pushBack({row-1, column});
      searched[row-1][column] = true;
    }
    if(searched[row+1][column] == false && maze(row+1, column) == WHITE){
      dq.pushBack({row+1, column});
      searched[row+1][column] =	true;
    }
    if(searched[row][column-1] == false && maze(row, column-1) == WHITE){
      dq.pushBack({row, column-1});
      searched[row][column-1] =	true;
    }
    if(searched[row][column+1] == false && maze(row, column+1) == WHITE){
      dq.pushBack({row, column+1});
      searched[row][column+1] =	true;
    }


  }

  writeToFile(maze, argv[2]);
  if(compare==true){
    std::cout<<"Solution Found"<<std::endl;
  }
  else{
    std::cout<<"No Solution Found"<<std::endl;
  }
}
