#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "array_list.hpp"

//force class expansion
template class ArrayList<int>;

TEST_CASE( "Test", "[ArrayList]" ) {

  ArrayList<int> list;
}

TEST_CASE("insert", "[Test 1]"){
  ArrayList<int> list;
  REQUIRE(list.insert(1,1));
}

TEST_CASE("insert2", "[Test 2]"){
  ArrayList<int> list;
  REQUIRE(list.insert(1,1));
  REQUIRE(list.insert(1,2));
  REQUIRE(list.getEntry(1)==2);
  REQUIRE(list.getEntry(2)==1);
}

TEST_CASE("clear", "[Test 3]"){
  ArrayList<int> list;
  list.insert(1,1);
  list.insert(2,1);
  list.insert(3,1);
  list.clear();
  REQUIRE(list.isEmpty());
}

TEST_CASE("set", "[Test 4]"){
  ArrayList<int> list;
  list.insert(1,1);
  list.setEntry(1,3);
  REQUIRE(list.getEntry(1)==3);
}

TEST_CASE("remove", "[Test 5]"){
  ArrayList<int> list;
  list.insert(1,1);
  list.insert(2,2);
  list.insert(3,3);
  list.remove(2);
  REQUIRE(list.getEntry(2)==3);
  REQUIRE(list.getLength()==2);
}
