#include <string>
using std::string;

#include <iostream>

#include <cctype> // for isalpha

#include "algebraic_expressions.hpp"

bool isoperator(char ch) {
  return ((ch == '+') || (ch == '-') || (ch == '/') || (ch == '*'));
}

int endPost(string s, int last) {
  int first = 0;

  if ((first > last)) {
    return -1;
  }

  char ch = s[last];
  if (isalpha(ch)) {
    return last;
  } else {
    if (isoperator(ch)) {
      int lastEnd = endPost(s, last - 1);
      if (lastEnd > -1) {
        return endPost(s, lastEnd - 1);
      } else {
        return -1;
      }
    } else {
      return -1;
    }
  }
}

bool isPost(string s) {
  int firstChar = endPost(s, s.size() - 1);

  return (firstChar == 0);
}

void convert(string &postfix, string &prefix) {
  string hold_op, hold_num,flip;
  int op_c, num_c;
  for(int i=0; i<postfix.size(); i++){
    if(isoperator(postfix[i])){
      hold_op += postfix.substr(i,1);
    }
      if(!(isoperator(postfix[i]))){
	    hold_num += postfix.substr(i,1);
    }
  }
  num_c = hold_num.size();
  op_c = hold_op.size();
  for(int i = 0; i<num_c; i++){
    flip += hold_num.substr((num_c-1)-i,1);
     	}
	hold_num=flip;
    prefix += hold_op.substr(op_c-1,1);
    op_c--;
	hold_op = hold_op.substr(0,op_c);
	int total_c = num_c + op_c;
	for(int i = total_c; i>0;i--){
    if(num_c>2){
      num_c--;
      prefix += hold_num.substr(num_c,1);
      op_c--;
      prefix += hold_op.substr(op_c,1);
      hold_num = hold_num.substr(0, num_c);
      hold_op = hold_op.substr(0, op_c);
   }
	}
	num_c--;
      prefix += hold_num.substr(num_c,1);
	num_c--;
	prefix += hold_num.substr(num_c,1);
}
