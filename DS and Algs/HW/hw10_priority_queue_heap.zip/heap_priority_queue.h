
#ifndef _HEAP_PRIORITY_QUEUE_H_
#define _HEAP_PRIORITY_QUEUE_H_

#include "abstract_priority_queue.h"
#include "dynamic_array_list.h"

template <typename T>
class HeapPriorityQueue: public AbstractPriorityQueue<T>
{
public:
    
    // return true if the priority queue is empty
    bool isEmpty();
    
    // insert item into the queue
    void add(const T& item);
    
    // remove highest priority item from the queue
    void remove();
    
    // get the item with the highest priority from the queue
    T peek();
    
private:
    
    DynamicArrayList<T> lst;
};

template <typename T>
bool HeapPriorityQueue<T>::isEmpty()
{
    lst.isEmpty();
}

template <typename T>
void HeapPriorityQueue<T>::add(const T& item)
{
    int count = 0;
    int s = lst.getLength();
    int parent = (s-1)/2;
    if(s == 0){
    	lst.insert(0, item);
    }
    else{
    	lst.insert(s, item);
    	while((parent >= 0) && (lst.getEntry(parent) < item)){
    		if(parent == 0){
    			count++;
    		}
    		if(count > 1){
    			break;
    		}
    		lst.setEntry(s, lst.getEntry(parent));
    		s = parent;
    		parent = (s-1)/2;
    	}
    	lst.setEntry(s, item);
    }
}

template <typename T>
void HeapPriorityQueue<T>::remove()
{
    int count = 0;
    int l, r, max, hold;
    if(lst.getLength() ==1){
    	lst.remove(0);
    }
    else{
    	lst.setEntry(0, lst.getEntry(lst.getLength()-1));
    	lst.remove(lst.getLength()-1);
    	while(count == 0){
    		l = hold*2 + 1;
    		r = hold*2 + 1;
    		max = hold;
    		if(r < lst.getLength() && lst.getEntry(r) > lst.getEntry(max)){
    			max = r;
    		}
    		if(l < lst.getLength() && lst.getEntry(l) > lst.getEntry(max)){
    			max = l;
    		}
    		if(max != hold){
    			T holder = lst.getEntry(hold);
    			lst.setEntry(hold, lst.getEntry(max));
    			lst.setEntry(max, holder);
    			hold = max;
    		}
    		else{
    			count++;
    		}
    	}
    }
}

template <typename T>
T HeapPriorityQueue<T>::peek()
{
    lst.getEntry(0);
   
}


#endif // _HEAP_PRIORITY_QUEUE_H_
