#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "bag.hpp"

// force template expansion
template class Bag<int>;

TEST_CASE("Empty Test", "[Bag]"){
  REQUIRE(true);
}

TEST_CASE("Empty Bag", "[Test 1]"){
  Bag<int> Test_Bag;
  REQUIRE(Test_Bag.isEmpty());
}

TEST_CASE("Item added", "[Test 2]"){
  Bag<int> Test_Bag;
  Test_Bag.add(5);
  bool Test2_Answer = !(Test_Bag.isEmpty());
  REQUIRE(Test2_Answer);
}

TEST_CASE("Item removed", "[Test 3]"){
  Bag<int> Test_Bag;
  Test_Bag.add(5);
  REQUIRE(Test_Bag.remove(5));
}

TEST_CASE("Number of Items", "[Test 4]"){
  Bag<int> Test_Bag;
  Test_Bag.add(5);
  Test_Bag.add(5);
  Test_Bag.add(5);
  REQUIRE(Test_Bag.getCurrentSize() == 3);
}

TEST_CASE("Frequency of Items", "[Test 5]"){
  Bag<int> Test_Bag;
  Test_Bag.add(5);
  Test_Bag.add(5);
  Test_Bag.add(5);
  REQUIRE(Test_Bag.getFrequencyOf(5) == 3);
}

TEST_CASE("Clear", "[Test 6]"){
  Bag<int> Test_Bag;
  Test_Bag.add(5);
  Test_Bag.add(5);
  Test_Bag.add(5);
  Test_Bag.clear();
  REQUIRE(Test_Bag.getFrequencyOf(5) == 0);
}

TEST_CASE("Contains", "[Test 7]"){
  Bag<int> Test_Bag;
  Test_Bag.add(5);
  Test_Bag.add(4);
  Test_Bag.add(3);
  REQUIRE(!(Test_Bag.contains(6)));
}

TEST_CASE("Contains 2", "[Test 8]"){
  Bag<int> Test_Bag;
  Test_Bag.add(5);
  Test_Bag.add(4);
  Test_Bag.add(3);
  REQUIRE(Test_Bag.contains(5));
}
