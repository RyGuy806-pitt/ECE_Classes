#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "dynamic_bag.hpp"

// force template expansion for ints
template class DynamicBag<int>;

TEST_CASE("Calling all public members", "[DynamicBag]"){
  DynamicBag<int> b;

  b.add(0);
  b.remove(0);
  b.isEmpty();
  b.getCurrentSize();
  b.clear();
  b.getFrequencyOf(0);
  b.contains(0);
}

TEST_CASE("add", "[Test 1]"){
  DynamicBag<int> b;
  b.add(0);
  REQUIRE(b.contains(0));
}

TEST_CASE("remove", "[Test 2]"){
  DynamicBag<int> b;
  b.add(0);
  b.add(1);
  b.add(2);
  b.remove(1);
  REQUIRE((b.contains(1) != true));
}

TEST_CASE("clear", "[Test 3]"){
  DynamicBag<int> b;
  b.add(0);
  b.add(2);
  b.add(3);
  b.clear();
  REQUIRE(b.isEmpty());
}

TEST_CASE("Empty", "[Test 4]"){
  DynamicBag<int> b;
  REQUIRE(b.isEmpty());
}

TEST_CASE("Size", "[Test 5]"){
  DynamicBag<int> b;
  b.add(0);
  b.add(0);
  b.add(1);
  REQUIRE(b.getCurrentSize()==3);
}

TEST_CASE("Frequency", "[Test 6]"){
  DynamicBag<int> b;
  b.add(0);
  b.add(1);
  b.add(0);
  b.add(1);
  b.add(0);
  b.add(2);
  b.remove(0);
  REQUIRE(b.getFrequencyOf(0)==2);
}
