#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "linked_list.hpp"

template class LinkedList<int>;

TEST_CASE( "TODO", "[LinkedList]" ) {
  
}

TEST_CASE( "insert", "[Test 1]"){
  LinkedList<int> list;
  list.insert(1,1);
  list.insert(2,2);
  REQUIRE(list.getEntry(2)==2);
}

TEST_CASE( "Empty", "[Test 2]"){
  LinkedList<int> list;
  REQUIRE(list.isEmpty());
}

TEST_CASE( "clear", "[Test 3]"){
  LinkedList<int> list;
  list.insert(1,1);
  list.clear();
  REQUIRE(list.isEmpty());
}

TEST_CASE( "insert2", "[Test 4]"){
  LinkedList<int> list;
  list.insert(1,1);
  list.insert(2,2);
  REQUIRE(list.getEntry(1)==1);
}

TEST_CASE( "insert3", "[Test 5]"){
  LinkedList<int> list;
  list.insert(1,1);
  list.insert(2,3);
  list.insert(2,2);
  REQUIRE(list.getEntry(3)==3);
  REQUIRE(list.getEntry(2)==2);
}

TEST_CASE( "swap", "[Test 6]"){
  LinkedList<int> list1;
  LinkedList<int> list2;
  list1.insert(1,1);
  list2.insert(1,2);
  list1.swap(list1, list2);
  REQUIRE(list1.getEntry(1)==2);
}

TEST_CASE("remove", "[Test 7]"){
  LinkedList<int> list;
  list.insert(1,1);
  list.insert(2,2);
  list.insert(3,3);
  list.remove(1);
  REQUIRE(list.getEntry(1)==2);
  REQUIRE(list.getEntry(2)==3);
}

TEST_CASE("setEntry", "[Test 8]"){
  LinkedList<int> list;
  list.insert(1,1);
  list.insert(2,0);
  list.setEntry(2, 2);
  REQUIRE(list.getEntry(2)==2);
}
