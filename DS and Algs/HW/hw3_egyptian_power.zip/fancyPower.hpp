#ifndef FANCYPOWER_HPP
#define FANCYPOWER_HPP

int fancyPower(int n, int m)
{
  if(n==0){
    return 1;
  }
  if(n%2==0)
    {
      return fancyPower(n/2, m*m);
    }
  if(n%2==1){
      return m*fancyPower((n-1)/2,m*m);
    }
  return 0;
}

#endif
