#define CATCH_CONFIG_MAIN
#include "catch.hpp"

#include "fancyPower.hpp"

// write your test cases here
TEST_CASE("Test case", "fancyPower"){

  REQUIRE(true);
  
}

TEST_CASE("Power 0", "[Test 1]"){
  REQUIRE(1==fancyPower(0,3));
}

TEST_CASE("8", "[Test 2]"){
  REQUIRE(8==fancyPower(3,2));
}

TEST_CASE("16", "[Test 3]"){
  REQUIRE(16==fancyPower(4,2));
}
